import { Text } from '@react-navigation/elements';
import { FlatList, StyleSheet, View, Image } from 'react-native';
import React from 'react';

export function List() {
  const data = Array.from({ length: 500 }, (_, index) => ({
    id: String(index + 1),
    title: `Item ${index + 1}`,
  }));

  const listItem = () => {
    return (
      <View style={styles.listItem}>
        <Image
           source={require('./account_circle.png')}
           style={styles.icon}
          />
        <View style={styles.textContainer}>
          <Text style={styles.header}>Überschrift</Text>
          <Text style={styles.subtitle}>Unterüberschrift</Text>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={data}
        renderItem={listItem}
        keyExtractor={item => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 0,
      backgroundColor: '#f5f5f5',
    },
    itemContainer: {
      padding: 16,
      backgroundColor: '#fff',
      borderBottomWidth: 1,
      borderBottomColor: '#ddd',
      borderRadius: 4,
      marginBottom: 8,
    },
    itemText: {
      fontSize: 16,
      color: '#333',
    },
    listItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingTop: 8,
      paddingBottom: 8,
      paddingStart: 16,
      paddingEnd: 16,
      height:72,
      borderBottomWidth: 1,
      borderBottomColor: '#ddd',
    },
    icon: {
      marginRight: 16,
      width: 24,
      height: 24
    },
    textContainer: {
      flex: 1,
    },
    header: {
      fontSize: 16,
    },
    subtitle: {
      fontSize: 14,
      color: 'gray',
    },
  });