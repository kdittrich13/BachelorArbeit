import { Text, Button } from '@react-navigation/elements';
import {StyleSheet, View } from 'react-native';
import React from 'react';
import LottieView from "lottie-react-native";

const localSource = require("./animation.json");

export function Animation() {
  const ref = React.useRef<LottieView>(null);
  const [source, setSource] = React.useState(localSource);
  const [isLoop, setLoop] = React.useState(false);

  return (
    <View style={styles.container}>
        <LottieView
            ref={ref}
            key={source + isLoop}
            source={source}
            autoPlay={false}
            loop={isLoop}
            style={styles.lottie}
            resizeMode={"contain"}
        />
        <View>
        <Button
            onPress={() => {
                ref.current?.play();
            }}
        >Start</Button>
        </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 32,
  },
  lottie: { width: 200, height: 200 },
});
