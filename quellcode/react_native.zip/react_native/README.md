# React Native Benchmark App

Features :
- Scrolling List
- Animation by Lottie

Build debug project with expo:
  ```sh
  npm run android
  ```

Build release:

npx react-native build-android --tasks assembleRelease

Path:

android/app/build/outputs/apk/release/app-release.apk



