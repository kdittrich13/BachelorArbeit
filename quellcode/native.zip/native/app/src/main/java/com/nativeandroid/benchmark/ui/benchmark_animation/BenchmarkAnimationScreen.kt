package com.nativeandroid.benchmark.ui.benchmark_animation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition
import com.nativeandroid.benchmark.R

@Composable
fun AnimationScreen() {

    var initial by remember { mutableStateOf(true) }
    var animationIsPlaying by remember { mutableStateOf(false) }
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.animation))

    val progress by animateLottieCompositionAsState(
        composition = composition,
        isPlaying = animationIsPlaying,
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LaunchedEffect(key1 = progress) {
            if (!initial) {
                if (progress == 0f) {
                    animationIsPlaying = true
                }
                if (progress == 1f) {
                    animationIsPlaying = false
                }
            }
        }

        LottieAnimation(
            composition = composition,
            progress = { progress },
            modifier = Modifier
                .height(200.dp)
                .width(200.dp)
        )

        Button(
            onClick = {
                if (initial) {
                    initial = false
                }
                animationIsPlaying = !animationIsPlaying
            },
        ) {
            Text(
                text = "Start"
            )
        }
    }
}


