Native Benchmark App

Features : 
- Scrolling List
- Animation by Lottie

Build release in project root:
```
gradle assembleRelease 
```

Path:
- app/build/outputs/apk/release/app-release.apk