global using BenchmarkMaui.Pages;
global using Fonts;
