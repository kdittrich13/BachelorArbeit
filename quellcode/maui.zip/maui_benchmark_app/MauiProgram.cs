﻿using CommunityToolkit.Maui;
using SkiaSharp.Views.Maui.Controls.Hosting;


namespace BenchmarkMaui
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .UseSkiaSharp()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("Roboto-Regular.ttf", "RobotoRegular");
                }).UseMauiCommunityToolkit();
            return builder.Build();
        }
    }
}