namespace BenchmarkMaui.Pages
{
    public partial class ScrollListPage : ContentPage
    {
        public ScrollListPage()
        {
            InitializeComponent();
        }
    }
    
}