﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Maui.Dispatching;
using SkiaSharp.Views.Maui.Controls;
using SkiaSharp;
using SkiaSharp.Views.Maui;
using System.ComponentModel.Design;
using SkiaSharp.Extended.UI.Controls;
using System.Diagnostics;
using System.Windows.Input;

namespace BenchmarkMaui.Pages
{
    public partial class AnimationPage : ContentPage
    {
        private TimeSpan progress;
        //https://github.com/mono/SkiaSharp.Extended/tree/main/samples/SkiaSharpDemo/Demos/Lottie

        public AnimationPage()
        {
            InitializeComponent();
            PlayPauseCommand = new Command(OnPlayPause);

            BindingContext = this;
        }


        public TimeSpan Progress
        {
            get => progress;
            set
            {
                progress = value;   


                OnPropertyChanged();
            }
        }

        public ICommand PlayPauseCommand { get; }

        private void OnPlayPause(){
            Progress = TimeSpan.Zero;
        }
            
        private void OnAnimationFailed(object sender, SKLottieAnimationFailedEventArgs e)
        {
            Debug.WriteLine($"Failed to load Lottie animation: {e.Exception}");
        }

        private void OnAnimationLoaded(object sender, SKLottieAnimationLoadedEventArgs e)
        {
            Debug.WriteLine($"Lottie animation loaded: {e.Size}; {e.Duration}; {e.Fps}");
        }

        private void OnAnimationCompleted(object sender, EventArgs e)
        {
            Debug.WriteLine("Lottie animation finished playing.");
        }

    }
}
