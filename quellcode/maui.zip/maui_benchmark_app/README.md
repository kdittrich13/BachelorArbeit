Maui Benchmark
