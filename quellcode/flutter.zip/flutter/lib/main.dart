import 'package:flutter/material.dart';
import 'package:flutter_benchmark_app/benchmark_animation.dart';
import 'benchmark_list.dart';
import 'utils/app_strings.dart';

void main() {
  runApp(const BenchmarkApp());
}

class BenchmarkApp extends StatelessWidget {
  const BenchmarkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppStrings.appName,
      home: const FirstRoute(),
    );
  }
}

class FirstRoute extends StatelessWidget {
  const FirstRoute({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.startScreen)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              child: const Text(AppStrings.button1Label),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const BenchmarkList()),
                );
              },
            ),
            ElevatedButton(
              child: const Text(AppStrings.button3Label),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const BenchmarkAnimation()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
