class AppStrings {
  // App Name
  static const String appName = 'Flutter Benchmark App';

  // First Route Screen
  static const String startScreen = 'Benchmark App Flutter';
  static const String button1Label = 'List';
  static const String button3Label = 'Animation';

  // Feature List Screen
  static const String featureListTitle = 'List';
  static const String featureAnimationTitle = 'Animation';
}