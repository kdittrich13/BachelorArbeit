import 'package:flutter/material.dart';
import 'package:flutter_benchmark_app/utils/app_strings.dart';

class BenchmarkList extends StatelessWidget {
  const BenchmarkList({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text(AppStrings.featureListTitle)),
      body: ListView.separated(
        itemCount: 500,
        separatorBuilder: (context, index) {
          return Divider(height: 1, color: Colors.grey);
        },
        itemBuilder: (context, index) {
          return Semantics(
            identifier: 'Item $index',
            label: 'Item $index',
            child: ListTile(
              contentPadding: const EdgeInsets.only(left: 16, right: 16),
              title: Text('Überschrift'),
              subtitle: Text('Unterüberschrift'),
              leading: const Icon(Icons.account_circle),
            ),
          );
        },
      ),
    );
  }
}
