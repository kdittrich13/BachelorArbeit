import 'package:flutter/material.dart';
import 'package:flutter_benchmark_app/utils/app_strings.dart';
import 'package:lottie/lottie.dart';

class BenchmarkAnimation extends StatefulWidget {
  const BenchmarkAnimation({super.key});

  @override
  State<BenchmarkAnimation> createState() => _BenchmarkAnimationState();
}

class _BenchmarkAnimationState extends State<BenchmarkAnimation>
    with TickerProviderStateMixin {
  late final AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(vsync: this);
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          AppStrings.featureAnimationTitle,
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset(
              width: 200,
              height: 200,
              fit: BoxFit.fill,
              'lib/assets/animation.json',
              controller: _animationController,
              onLoaded: (composition) {
                setState(() {
                  _animationController.duration = composition.duration;
                });
              },
            ),
            ElevatedButton(
              child: const Text("Start"),
              onPressed: () {
                _animationController.repeat(count: 1);
              },
            ),
          ],
        ),
      ),
    );
  }
}
