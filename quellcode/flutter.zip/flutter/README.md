# Flutter Benchmark App
Features :

- Scrolling List
- Animation by Lottie

Build release in project root:

```
flutter build apk
```

Path:
- build/app/outputs/flutter-apk/app-release.apk
