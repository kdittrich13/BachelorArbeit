package com.flutter.benchmark.flutter_benchmark_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
