Kotlin Multiplatform Benchmark App

Benchmarks :
    Liste
    Animation

Release Version :
- Android Studio > Build Variants > release

Path:
- composeApp/build/intermediates/apk/release/composeApp-release.apk
