import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun ListScreen() {
    LazyColumn {
        items(500) {
            ListItem(
                leadingContent = {
                    Icon(
                        Icons.Default.AccountCircle,
                        contentDescription = "icon"
                    )
                },
                headlineContent = { Text("Überschrift") },
                supportingContent = { Text("Unterüberschrift") },
            )
            HorizontalDivider()
        }
    }
}