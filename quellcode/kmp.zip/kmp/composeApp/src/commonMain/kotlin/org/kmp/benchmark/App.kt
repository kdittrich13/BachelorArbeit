package org.kmp.benchmark

import AnimationScreen
import ListScreen
import MainScreen
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController


enum class FeatureScreen(val title: String) {
    Start(title = "Benchmark App KMP"),
    ListBenchmark(title = "List"),
    AnimationBenchmark(title = "Animation"),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BenchmarkAppBar(
    currentScreen: FeatureScreen,
    canNavigateBack: Boolean,
    navigateUp: () -> Unit,
    modifier: Modifier = Modifier
) {
    TopAppBar(
        title = { Text(currentScreen.title) },
        colors = TopAppBarDefaults.mediumTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        modifier = modifier,
        navigationIcon = {
            if (canNavigateBack) {
                IconButton(onClick = navigateUp) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Zurück"
                    )
                }
            }
        }
    )
}

@Composable
fun App(
    navController: NavHostController = rememberNavController()
) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentScreen = FeatureScreen.valueOf(
        backStackEntry?.destination?.route ?: FeatureScreen.Start.name
    )

    Scaffold(
        topBar = {
            BenchmarkAppBar(
                currentScreen = currentScreen,
                canNavigateBack =  navController.previousBackStackEntry != null,
                navigateUp = {navController.navigateUp()}
            )
        }) { paddingValues ->

        NavHost(
            navController = navController,
            startDestination = FeatureScreen.Start.name,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(route = FeatureScreen.Start.name) {
                MainScreen(
                    onClickToList = { navController.navigate(FeatureScreen.ListBenchmark.name) },
                    onClickFeature3 = { navController.navigate(FeatureScreen.AnimationBenchmark.name) },
                )
            }
            composable(route = FeatureScreen.ListBenchmark.name) {
                ListScreen()
            }
            composable(route = FeatureScreen.AnimationBenchmark.name) {
                AnimationScreen()
            }
        }
    }
}